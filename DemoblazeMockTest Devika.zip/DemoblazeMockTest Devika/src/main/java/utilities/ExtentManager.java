package utilities;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentManager {
	public static ExtentReports extent;
	public static ExtentSparkReporter htmlReporter;
	
	public static ExtentReports createInstance() {
		//String repname = "TestReport-"+ SetUp.getTimeStamp()+".html";
		String repname = "TestReport-"+".html";
		htmlReporter = new ExtentSparkReporter(System.getProperty("user.dir")+ "//Reports//"+repname);
		
		htmlReporter.config().setDocumentTitle("Extent Report Demo");
		htmlReporter.config().setReportName("Test Report");
		htmlReporter.config().setTimelineEnabled(true);
		htmlReporter.config().setTheme(Theme.DARK);
		htmlReporter.config().setTimeStampFormat("MM/dd/yyyy HH:mm:ss");
		
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("OS","Windows");
		extent.setSystemInfo("Host Name","localhost");
		extent.setSystemInfo("Environment","QA");
		extent.setSystemInfo("Username","Devika");
		
		return extent;
		
		
	}


}
