package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;


public class HomePage {
	WebDriver driver;
	LoginPage lp;
	ReusableFunctions rf;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunctions(driver);
	}
	
	@FindBy(id="login2")
	public WebElement LogIn;
	
	@FindBy(id="signin2")
	public WebElement SignIn;
	
	public SignUpPage clickElement(WebElement el) {
		rf.clickElement(el);
		return new SignUpPage(driver);
	}
	public LoginPage clickLogin(WebElement el) {
		rf.clickElement(el);
		return new LoginPage(driver);
	}
	
	

}
