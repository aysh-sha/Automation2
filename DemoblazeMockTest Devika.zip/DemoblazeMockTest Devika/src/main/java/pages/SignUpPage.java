package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import base.ReusableFunctions;



public class SignUpPage {
	public WebDriver driver;
	public ReusableFunctions rf;
	
	public SignUpPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
		rf=new ReusableFunctions(driver);
	}
	
	@FindBy(id="sign-username")
	public WebElement SignUpUserName;
	
	@FindBy(id="sign-password")
	public WebElement SignUpPwd;
	
	@FindBy(xpath="//div[@id='signInModal']//div[3]/button[2]")
	public WebElement SignUpBtn;
	
	public void enterText(WebElement el,String txt) {
		rf.insertText(txt, el);
	}
	
	public void clickBtn(WebElement el) {
		rf.clickElement(el);
	}
	

}
