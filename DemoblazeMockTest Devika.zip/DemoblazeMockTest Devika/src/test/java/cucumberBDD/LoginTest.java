package cucumberBDD;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.WebDriver;


import base.SetUp;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.HomePage;
import pages.LoginPage;

public class LoginTest extends SetUp{
	public LoginTest() throws IOException {
		super();
		
	}
	WebDriver driver;
	LoginPage lp;
	HomePage hp;
	
	@Before
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("BaseUrl"));
		hp = new HomePage(driver);
	}

	@After
	public void teardown()  {
		
		driver.close();
	}
	
	
	@Given("the user in the Demoblaze Home Page")
	public void the_user_in_the_demoblaze_home_page() {
		lp = hp.clickLogin(hp.LogIn);
		
	}
	@Given("the login button is clicked")
	public void the_login_button_is_clicked() {
		lp = new LoginPage(driver);
		lp.clickBtn(lp.LoginBtn);
	}
	@Then("appropriate error message should be displayed or user should stay in same page")
	public void appropriate_error_message_should_be_displayed_or_user_should_stay_in_same_page() {
	    String alertText = driver.switchTo().alert().getText();
	    driver.switchTo().alert().accept();
	    assertTrue(alertText.contains(prop.getProperty("alertTextErrorLogin")),"Couldn't find error message !");
	}
	@When("the valid username is entered")
	public void the_valid_username_is_entered() {
		lp.enterText(lp.Login_username, prop.getProperty("login_username"));
	  
	}
	@When("valid password is entered")
	public void valid_password_is_entered() {
		lp.enterText(lp.Login_password, prop.getProperty("login_password"));
	    
	}
	@Then("user should be able to login successfully")
	public void user_should_be_able_to_login_successfully() {
		lp.waitUntil(lp.WelcomeMsg);
		assertTrue(lp.isPresent(lp.WelcomeMsg), "Login Error!");
	}
	
	
	

}
