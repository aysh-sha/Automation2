package testcases;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import base.SetUp;
import pages.HomePage;
import pages.LoginPage;
import pages.SignUpPage;
import utilities.ExcelReader;
import utilities.ExtentReportListener;

@Listeners(ExtentReportListener.class)
public class SignUpTest extends SetUp {
	HomePage hp;
	SignUpPage sp;
	LoginPage lp;

	public SignUpTest() throws IOException {
		super();

	}

	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("BaseUrl"));
		hp = new HomePage(driver);
	}

	@AfterTest
	public void teardown() {
		driver.quit();
	}

	@Test(priority = 0)
	public void sign_up_without_data() {
		sp = hp.clickElement(hp.SignIn);
		sp = new SignUpPage(driver);
		sp.clickBtn(sp.SignUpBtn);
		String alertText = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();

		assertTrue(alertText.contains(prop.getProperty("alertTextErrorMessage")), "Cannot find error message ! ");
	}

	@Test(priority = 1, dataProvider = "registration_validation")
	public void sign_up_with_data(String username, String password) {
		sp.enterText(sp.SignUpUserName, username);
		sp.enterText(sp.SignUpPwd, password);
		sp.clickBtn(sp.SignUpBtn);
		String signupAlert = driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		assertTrue(signupAlert.contains(prop.getProperty("successful_Signup")), "Sign Up Failed");

	}

	@DataProvider
	public String[][] registration_validation() throws IOException {
		String path = System.getProperty("user.dir") + "\\DataSource\\dataset.xlsx";
		String sheetname = "Sheet1";
		String[][] data = ExcelReader.getExcelData(path, sheetname);
		return data;

	}
}
