package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class BrowserImplementation {
	WebDriver driver;
	
	public WebDriver LaunchChrome() {
		String path="C:\\Users\\271559\\Desktop\\Java\\com.ust.ContactPage\\ChromeBrowser\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver",path);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		return driver;
	}
	public WebDriver LaunchEdge() {
		
		driver = new EdgeDriver();
		return driver;
	}


}
