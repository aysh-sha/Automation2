package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class LandingPage {
	
	WebDriver driver;
	

	public LandingPage(WebDriver driver){
		this.driver= driver;
	}
	
	public void verify_URL(){
		
		//String path= "C:\\Users\\271559\\Desktop\\Java\\com.ust.Petstore\\BrowserDriver\\chromedriver.exe";
		//System.setProperty("webdriver.chrome.driver", path);
		//driver = new EdgeDriver();
		
		
		//driver.get("https://www.ajio.com/");
		String title = driver.getTitle();
		System.out.println(title);
	}	
		public void verifySearchfunc(){
		driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[3]/div[2]/form/div/div/input")).sendKeys("Shoe" +Keys.ENTER);
		
		
		
	}

}
