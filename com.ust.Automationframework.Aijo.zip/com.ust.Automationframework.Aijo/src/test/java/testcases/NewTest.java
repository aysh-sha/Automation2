package testcases;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pages.LandingPage;
import utils.BrowserImplementation;

public class NewTest {
	LandingPage lp;
	WebDriver driver;
	BrowserImplementation bi;

	
  @Test
  public void TestLandingPage() {
	  bi = new BrowserImplementation();
	  driver = bi.LaunchChrome();
	  driver.get("https://www.ajio.com/");
	  lp= new LandingPage(driver);
	  String expURL="https://www.ajio.com/search/?text=shoe";
      driver.get(expURL);
	  String actualURL= driver.getCurrentUrl();
	  assertEquals(expURL,actualURL);
	  lp.verify_URL();
	  lp.verifySearchfunc();
	  
	  
	  
  }
}
