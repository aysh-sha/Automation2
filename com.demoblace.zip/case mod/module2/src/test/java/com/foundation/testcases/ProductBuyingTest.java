package com.foundation.testcases;

import static org.testng.Assert.assertEquals;


import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.foundation.base.ReusableFunctions;
import com.foundation.pages.BackCoverPage;
import com.foundation.pages.HomePage;
import com.foundation.pages.MobileCoverPage;
import com.foundation.pages.MobileTypePage;
import com.foundation.pages.ProductCartPage;
import com.foundation.utils.ExtentReportsListener;


@Listeners(ExtentReportsListener.class)
public class ProductBuyingTest {
	ReusableFunctions rfs;
	HomePage homepage;
	MobileCoverPage mobilecover;
	MobileTypePage mobileType;
	BackCoverPage backCoverPage;
	ProductCartPage productCartPage;
	
	@BeforeClass
	public void setup() {
		rfs = new ReusableFunctions();
		rfs.appInit();
		rfs.navigateTo();
	}
	
	@Test
	public void clickOnMobileCovers() {
		
		homepage = new HomePage(rfs.driver);
		homepage.ClickMobileCoverLink();
		System.out.println(rfs.driver.getCurrentUrl());
		assertEquals(rfs.driver.getCurrentUrl(),"https://casekaro.com/pages/mobile-back-covers");
	}
	
	@Test(dependsOnMethods = "clickOnMobileCovers")
	public void chooseMobile() {
		mobilecover = new MobileCoverPage(rfs.driver);
		mobilecover.ClickAppleCoverLink();
		System.out.println(rfs.driver.getCurrentUrl());
		assertEquals(rfs.driver.getCurrentUrl(),"https://casekaro.com/pages/mobile-back-covers");
	}
	
	@Test(dependsOnMethods = "chooseMobile")
	public void chooseMobileSeries() {
		mobileType = new MobileTypePage(rfs.driver, rfs.driver.getWindowHandle());
		backCoverPage = mobileType.selectPhone();
		assertEquals(true, backCoverPage.isBackCoverPresent());
	}
	
	@Test(dependsOnMethods = "chooseMobileSeries")
	public void buyItem() {
		productCartPage =  backCoverPage.clickIphoneCover();
		productCartPage = productCartPage.clickBuyOption();
		productCartPage.setMobileNumber("9061475611");
		assertEquals(true,productCartPage.isCartSummaryPresent());
		
	}

	@AfterClass
	public void closeTestClass() {
		rfs.tearDown();
	}
}
