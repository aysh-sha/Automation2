package com.foundation.stepdefenitions;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import com.foundation.base.ReusableFunctions;
import com.foundation.pages.HomePage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class TrackOrderSteps {
	ReusableFunctions rfs;
	WebDriver driver;
	HomePage homepage;
	
	
	@Before
	public void setup() {
		rfs = new ReusableFunctions();
		rfs.appInit();
		this.driver = rfs.driver;
		rfs.navigateTo();
	}
	
	@Given("user alreday on homepage")
	public void user_alreday_on_homepage() {
	    assertEquals(driver.getCurrentUrl(), rfs.testconfig.getUrl());
	    
	}
	@When("user clicks on track order")
	public void user_clicks_on_track_order() {
	    homepage = new HomePage(driver);
	    homepage.clickTrackOrder();
	   
	}
	@Then("user on track order page")
	public void user_on_track_order_page() {
	    // Write code here that turns the phrase above into concrete actions
	    assertEquals(driver.getCurrentUrl(),"https://casekaro.com/pages/track-order-1");
	}
	
	@After
	public void closeStep() {
		rfs.tearDown();
	}
	

}
