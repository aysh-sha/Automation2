package com.foundation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.foundation.base.ReusableFunctions;

public class LoginPage {
	ReusableFunctions rfs;
	WebDriver driver;
	
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
}
