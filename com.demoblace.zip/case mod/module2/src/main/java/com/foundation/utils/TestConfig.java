package com.foundation.utils;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:config/configuration.properties")
public interface TestConfig extends Config {
	
	//Gets the browser to be used for the tests.	
    @Key("BROWSER")
    
    //Default: "edge"   
    @DefaultValue("edge")
    String getBrowser();
    
    //Gets the base URL of the Lenskart website.
    @Key("BASE_PATH")
    String getUrl();

}
