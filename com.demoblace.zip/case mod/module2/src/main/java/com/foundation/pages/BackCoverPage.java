package com.foundation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.foundation.base.ReusableFunctions;

public class BackCoverPage {
	ReusableFunctions rfs;
	WebDriver driver;
	public BackCoverPage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(css = "ul[id='product-grid'] > li:nth-child(2)")
	private WebElement iphoneCover;
	
	public ProductCartPage clickIphoneCover() {
		rfs.wait.until(ExpectedConditions.visibilityOf(iphoneCover));
		iphoneCover.click();
		return new ProductCartPage(this.driver);
	}
	
	public boolean isBackCoverPresent() {
		return rfs.wait.until(ExpectedConditions.visibilityOf(iphoneCover)).isDisplayed();
	}
}
