package com.foundation.base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Set;

import org.aeonbits.owner.ConfigFactory;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.foundation.utils.TestConfig;


public class ReusableFunctions {
	public static final TestConfig testconfig = ConfigFactory.create(TestConfig.class);
	public WebDriver driver;
	public WebDriverWait wait;
	
	public void appInit() {
		driver = invokeBrowser();
		wait = setWait(driver, 10);
		
	}
	
	public void appInit(WebDriver driver) {
		this.driver = driver;
		wait = setWait(this.driver, 10);
	}
	
	// Create a WebDriverWait object with a specified wait timeout
    public  WebDriverWait setWait(WebDriver driver, int seconds) {
    	return
    		new WebDriverWait(driver, Duration.ofSeconds(seconds));
         
    }

    // Create an Actions object to perform user interactions on the web page
    public  Actions setActions(WebDriver driver) {
        return new Actions(driver);
    }

    // Navigate to the specified URL
    public  void navigateTo() {
        String url = testconfig.getUrl();
        driver.navigate().to(url);
    }
	
	
	// Launch the browser based on the configuration
    public static WebDriver invokeBrowser() {

        String browser = testconfig.getBrowser();

        switch (browser) {

            case "chrome":
                ChromeOptions chromeoptions = new ChromeOptions();
                chromeoptions.addArguments("--disable-notifications", "--start-maximized");
                chromeoptions.addArguments("--guest");
                return new ChromeDriver(chromeoptions);

            case "edge":
                EdgeOptions edgeoptions = new EdgeOptions();
                edgeoptions.addArguments("--disable-notifications", "--start-maximized");
                edgeoptions.addArguments("--guest");
                return new EdgeDriver(edgeoptions);

            default:
                System.out.println("Browser not configured: " + browser);
                return null;

        }

    }
    
    public void tearDown() {
    	if (driver != null)
    		driver.quit();
    }
    
    public WebDriver changeWindow(WebDriver driver, String parentWindow) {
    	 Set<String> windows = driver.getWindowHandles();
         for (String window : windows) {
             if (!window.equals(parentWindow)) {
                 driver.switchTo().window(window);
                 break;
             }
         }
         return driver;
    }
    
    public void setImplicitWait() {
    	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    
    public void delay() {
    	try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
   
    
    public  void takeScreenshot(String filepath) {
    	TakesScreenshot takeScreenShot = (TakesScreenshot) driver;
        File srcFile = takeScreenShot.getScreenshotAs(OutputType.FILE);
        File destFile = new File(filepath);
        try {
            FileUtils.copyFile(srcFile, destFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
	
	
	

}
