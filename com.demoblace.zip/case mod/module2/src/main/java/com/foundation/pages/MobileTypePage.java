package com.foundation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.foundation.base.ReusableFunctions;

public class MobileTypePage {
	ReusableFunctions rfs;
	WebDriver driver;
	
	public MobileTypePage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();		
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	public MobileTypePage(WebDriver driver, String window) {
		rfs = new ReusableFunctions();
		this.driver = rfs.changeWindow(driver, window);
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//div[text()='iPhone 15']")
	private WebElement iphone15;
	
	public BackCoverPage selectPhone() {
		rfs.wait.until(ExpectedConditions.visibilityOf(iphone15));
		iphone15.click();
		return new BackCoverPage(driver);
	}
}
