package com.foundation.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.foundation.base.ReusableFunctions;

public class MobileCoverPage {
	
	ReusableFunctions rfs;
	WebDriver driver;
	
	public MobileCoverPage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	
	
	@FindBy(xpath = "//a[text()='Apple']")
	private WebElement appleCoverLink;
	
	public void ClickAppleCoverLink() {
		rfs.wait.until(ExpectedConditions.visibilityOf(appleCoverLink));
		appleCoverLink.click();
		
	}
}
