package com.foundation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.foundation.base.ReusableFunctions;

public class HomePage {
	ReusableFunctions rfs;
	WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//span[text() ='Track Order']")
	private WebElement trackOrder;
	
	@FindBy(xpath = "//span[text()='Mobile Covers']")
	private WebElement mobileCoverLink;
	
	public void ClickMobileCoverLink() {
		rfs.wait.until(ExpectedConditions.visibilityOf(mobileCoverLink));
		mobileCoverLink.click();
	}
	
	public void clickTrackOrder() {
		trackOrder.click();
	}
	
}
