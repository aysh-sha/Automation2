package com.foundation.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.foundation.base.ReusableFunctions;

public class ProductCartPage {
	
	ReusableFunctions rfs;
	WebDriver driver;
	
	public ProductCartPage(WebDriver driver) {
		this.driver = driver;
		rfs = new ReusableFunctions();		
		rfs.appInit(this.driver);
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(css = "button[id=gokwik-buy-now]")
	private WebElement productBuy;
	
	@FindBy(css = "input[placeholder='Enter Number']")
	private WebElement numberInput;
	
	@FindBy(xpath = "//h4[text()='order summary']")
	private WebElement cartSummary;
	
	
	
	public ProductCartPage clickBuyOption() {
		rfs.wait.until(ExpectedConditions.visibilityOf(productBuy));
		productBuy.click();
		rfs.delay();
		WebElement iframe = rfs.driver.findElement(By.cssSelector("iframe[title='Checkout window']"));
		return new ProductCartPage(rfs.driver.switchTo().frame(iframe));
		
		
	}
	
	public void setMobileNumber(String mobileNo) {
		rfs.wait.until(ExpectedConditions.visibilityOf(numberInput));
		numberInput.sendKeys(mobileNo);
		rfs.delay();
		
	}
	
	public boolean isCartSummaryPresent() {
		return
		rfs.wait.until(ExpectedConditions.visibilityOf(cartSummary)).isDisplayed();
		
		
	}

}
