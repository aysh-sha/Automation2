package com.ust.demoblaze.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.demoblaze.base.Setup;
import com.ust.demoblaze.pages.HomePageImpl;
import com.ust.demoblaze.pages.SignupPopUpImpl;
import com.ust.demoblaze.utilities.EventListenerClass;
import com.ust.demoblaze.utilities.ExcelReader;
import com.ust.demoblaze.utilities.ObjectReader;
//AUTHOR: ABHINAV SELVARAJAN
//TEST FOR THE SIGNUP OF THE SITE
@Listeners(EventListenerClass.class)
public class SignupVerificationTest {
	WebDriver driver;
	HomePageImpl homePageImpl;
	SignupPopUpImpl signupPopUpImpl;
	Properties properties;

	@BeforeClass
	public void beforeclass() {
		properties = ObjectReader.initProperties();// Initializing poperties
		driver = Setup.invokeBrowser(properties.getProperty("browser"));// opening browser
		driver.get(properties.getProperty("baseurl"));// opening the site
		driver.manage().timeouts().implicitlyWait(Duration.ofMinutes(1));// implicite wait of 1 minute
	}
	@AfterClass
	public void teardown() {
		driver.quit();
	}

	@Test(priority = 1, dataProvider = "testdata") // taking data from the data provider and second priority
	public void signup(String uname, String pswd) {// taking value as uname and pswd from multidimesnional string
		homePageImpl = new HomePageImpl(driver);
		signupPopUpImpl = homePageImpl.clicksignupbtn();
		signupPopUpImpl.enterusername(uname);
		signupPopUpImpl.enterpassword(pswd);
		signupPopUpImpl.clicksignup();
		String alertdata = signupPopUpImpl.alertfound();
		if (alertdata != "Sign up successful.") {
			signupPopUpImpl.closepopup();
			assertEquals(alertdata, "This user already exist.");// If the user already exist then should show this error
																// message
		} else
			assertTrue(alertdata.equals("Sign up successful."));// If the user not exist should be able to sign in

	}

	@Test(priority = 0)
	public void verifyurl() {
		String actual = Setup.geturlOf(driver);
		assertEquals(actual, "https://www.demoblaze.com/index.html");//JUST VERIYING THAT THE SITE IS CORRECT
	}

	@DataProvider
	public String[][] testdata() {
		String datapath = System.getProperty("user.dir") + "/src/test/resources/datasource/Data.xlsx";//FETCHING DATA FROM EXCELL 
		return ExcelReader.getData(datapath, "credentials");//BY PASING THE XCELL LOCATION AND ITS SHEET NAME
	};

}
