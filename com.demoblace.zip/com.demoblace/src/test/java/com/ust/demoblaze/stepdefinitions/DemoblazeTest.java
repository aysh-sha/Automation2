package com.ust.demoblaze.stepdefinitions;

import static org.testng.Assert.assertEquals;

import java.util.Properties;

import org.openqa.selenium.WebDriver;

import com.ust.demoblaze.base.Setup;
import com.ust.demoblaze.pages.ContactusPopUpImpl;
import com.ust.demoblaze.pages.HomePageImpl;
import com.ust.demoblaze.utilities.ObjectReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//AUTHOR: ABHINAV SELVARAJAN
//CUCUMBER TEST DEFINITION FOR THE FEATURE CONTACT
public class DemoblazeTest {
	WebDriver driver;
	HomePageImpl homePageImpl;
	ContactusPopUpImpl contactusPopUpImpl;
	Properties properties;

	@Before
	public void beforemethod() {
		properties = ObjectReader.initProperties();
		driver = Setup.invokeBrowser(properties.getProperty("browser"));

	}
	@After
	public void aftermethod() {
		driver.quit();
	}

	@Given("user in the home page")
	public void user_in_the_home_page() {
		driver.get(properties.getProperty("baseurl"));

	}

	@When("user click the contact us button")
	public void user_click_the_contact_us_button() {
		homePageImpl = new HomePageImpl(driver);
		contactusPopUpImpl = homePageImpl.clickcontactus();

	}

	@And("Enter the {string} mail id")
	public void enter_the_mail_id(String mail) {
		contactusPopUpImpl.entermail(mail);

	}

	@And("Enter the {string} contact name")
	public void enter_the_contact_name(String name) {
		contactusPopUpImpl.entername(name);

	}

	@And("Enter the {string} message")
	public void enter_the_message(String message) {
		contactusPopUpImpl.entermessage(message);

	}

	@And("User Click send message")
	public void user_click_send_message() {
		contactusPopUpImpl.clicksendmsg();
	}

	@Then("Display an alert box with text {string}")
	public void display_an_alert_box_with_text(String expmessage) {
		System.out.println("The message " + expmessage);
		String alertmsg = contactusPopUpImpl.getalertboxmessage();
		assertEquals(alertmsg, expmessage);

	}

}
