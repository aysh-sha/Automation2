package com.ust.demoblaze.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = {
		"C:\\Users\\271499\\Documents\\EXAM\\com.demoblace\\src\\test\\resources\\features" }, glue = {
				"com.ust.demoblaze.stepdefinitions" }, publish = true, plugin = {
						"me.jvt.cucumber.report.PrettyReports:reports/cucumber" }

)

public class DemoblazeRunner extends AbstractTestNGCucumberTests {

}
