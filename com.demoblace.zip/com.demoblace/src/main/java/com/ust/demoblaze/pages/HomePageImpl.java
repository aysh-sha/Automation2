package com.ust.demoblaze.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//************************IMPLEMENTATION OF HOMEPAGE ********************
public class HomePageImpl {
	WebDriver driver;

	public HomePageImpl(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(linkText = "Contact")
	WebElement contact;
	@FindBy(linkText = "Sign up")
	WebElement signupbtn;

	public SignupPopUpImpl clicksignupbtn() {
		signupbtn.click();//CLICKING THE SIGNUP BUTTON
		return new SignupPopUpImpl(driver);//PASSING DRIVER TO SIIGNUPPOPUP CLASS

	}

	public ContactusPopUpImpl clickcontactus() {
		contact.click();//CLICKING CONTACT BUTTON
		return new ContactusPopUpImpl(driver);//PASSING DRIVER TO CONTACTPOPUP CLASS
	}

}
