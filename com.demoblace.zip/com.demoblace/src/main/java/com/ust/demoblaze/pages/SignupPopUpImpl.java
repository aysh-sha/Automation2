package com.ust.demoblaze.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
//*********************IMPLEMENTATION OF SIGNUP POPUP*****************
public class SignupPopUpImpl {
	WebDriver driver;

	public SignupPopUpImpl(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "sign-username")
	WebElement username;
	@FindBy(css = "#sign-password")
	WebElement paswd;
	@FindBy(xpath = "//button[text()='Sign up']")
	WebElement signupbtn;
	@FindBy(xpath = "(//button[text()='Close'])[2]")
	WebElement closepopbtn;

	public void enterusername(String uname) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		//wait.until(d -> username.isDisplayed());//USED LAMDA FUNCTION WAITING FOR THE USERNAME FIELD
		username.clear();//CLEARING THE USERNAME FIELD
		username.sendKeys(uname);//ENTERING DATA TO USERNAME FIELD

	}

	public void enterpassword(String pswd) {
		paswd.clear();//CLEARING PASSWORD FIELD
		paswd.sendKeys(pswd);//ENTERING DATA TO PASSWORD

	}

	public void clicksignup() {
		// paswd.sendKeys(Keys.TAB, Keys.TAB, Keys.ENTER);
		signupbtn.click();//CLICKING SIGNUP BUTTON

	}

	public String alertfound() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.alertIsPresent());
		Alert alert = driver.switchTo().alert();//WAITING FOR THE ALERT
		String alertdata = alert.getText();//FETCHING THE ALERT MESSAGE
		System.out.println("Alert data" + alertdata);//JUST PRINTING THE ALERT MESSAGE
		// if(alertdata.equals("Sign up successful."))
		alert.accept();//ACCEPTING ALERT
		return alertdata;//RETURING ALERT MESSAGE
	}

	public void closepopup() {
		// This user already exist.
		closepopbtn.click();//CLICKING THE CLOSE BUTTON IN THE POP UP
	}

}
