package com.ust.demoblaze.pages;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.demoblaze.base.Setup;
//**************************IMPLEMENTATION OF CONTACT US POPUP********************
public class ContactusPopUpImpl {
	WebDriver driver;

	public ContactusPopUpImpl(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);//USING PAGE FACTORY
	}

	@FindBy(css = "#recipient-email")
	WebElement mailfield;
	@FindBy(id = "recipient-name")
	WebElement namefield;
	@FindBy(xpath = "//textarea[@id='message-text']")
	WebElement messagefield;
	@FindBy(xpath = "//button[text()='Send message']")
	WebElement senmsgbtn;

	public void entermail(String mail) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		//wait.until(d -> mailfield.isDisplayed());//WAIT UNTIL THE USER NAME FIELD SHOWS UP
		mailfield.sendKeys(mail);//ENTERING DATA

	}

	public void entername(String name) {
		namefield.sendKeys(name);//ENTERING DATA

	}

	public String getalertboxmessage() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.alertIsPresent());//WAIT FOR ALERT POPUP
		Alert alert = driver.switchTo().alert();
		String alertmsg = alert.getText();//FETCHING TEXT FROM ALERT
		alert.accept();//ACCEPTING ALERT
		return alertmsg;

	}

	public void entermessage(String message) {

		messagefield.sendKeys(message);
		Setup.wait(1);//JUST WAITING TO SHOW THE DATA
	}

	public void clicksendmsg() {
		senmsgbtn.click();

	}
}
