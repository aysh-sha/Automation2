package com.ust.demoblaze.base;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.ust.demoblaze.utilities.ObjectReader;
//*****************************SETUP AND REUSABLE FUNCTIONS **********************
public class Setup {
	public static WebDriver driver;
	public static Properties prop;

	public Setup() {
		prop = ObjectReader.initProperties();
	}

	public static WebDriver invokeBrowser(String brow_choice) {

		try {
			if (brow_choice.equalsIgnoreCase("chrome"))
				driver = BrowserImplementation.chromeD();
			else if (brow_choice.equalsIgnoreCase("edge"))
				driver = BrowserImplementation.edgeD();
			else
				throw new Exception("Invalid browser name");
		} catch (Exception e) {
			e.getMessage();
		}
		return driver;
	}

//	public static void takescreenshot()  {
//		File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//		String path = System.getProperty("user.dir")+"/src/test/resources/screenshots/error on"+System.nanoTime()+".png";
//		File file = new File(path);
//		try {
//			FileUtils.copyFile(screenshotFile, file);
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
//	}

	public static void takescreenshot(String filpath) {
		TakesScreenshot takescreenshot = (TakesScreenshot) driver;
		File ssfile = takescreenshot.getScreenshotAs(OutputType.FILE);
		File destfile = new File(filpath);
		try {
			FileUtils.copyFile(ssfile, destfile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static String getTimeStamb() {
		return new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
	}

	public static String geturlOf(WebDriver driver) {
		return driver.getCurrentUrl();

	}

	public static void wait(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
