package com.stackroute.restassureddemos;



public class Category {
	
	private String catyid;
	private String catyname;
	
	public Category() {
		
	}

	public Category(String catyid, String catyname) {
		super();
		this.catyid = catyid;
		this.catyname = catyname;
	}

	public String getCatyid() {
		return catyid;
	}

	public void setCatyid(String catyid) {
		this.catyid = catyid;
	}

	public String getCatyname() {
		return catyname;
	}

	public void setCatyname(String catyname) {
		this.catyname = catyname;
	}
	
		

}

