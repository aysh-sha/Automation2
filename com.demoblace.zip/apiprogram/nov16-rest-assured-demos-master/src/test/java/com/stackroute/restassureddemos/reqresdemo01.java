package com.stackroute.restassureddemos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


class reqresdemo01 {

	final static private String BASEURL = "https://reqres.in/api/users";
	
	@Test
	public void testCreateUser() {
	RestAssured.useRelaxedHTTPSValidation();
		RestAssured.baseURI = BASEURL;
		
		RequestSpecification request = RestAssured.given();
		
		// setting the header
		request.header("Content-Type","application/json");
		
		JSONObject requestdata = new JSONObject();
		requestdata.put("name", "Chris");
		requestdata.put("job", "Supervisor");
		
		// setting the requestbody
		request.body(requestdata.toJSONString());
		
		Response response = request.post(BASEURL);
		
		int expectedstatuscode = 201;
		int actualstatuscode = response.statusCode();
		
		assertEquals(expectedstatuscode, actualstatuscode);
		
		assertTrue(response.body().asPrettyString().contains("Chris"));
		
		
		
	}

	
}
