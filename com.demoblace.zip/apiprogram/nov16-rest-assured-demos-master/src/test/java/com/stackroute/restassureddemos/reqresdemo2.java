package com.stackroute.restassureddemos;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.lessThan;

import java.io.File;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import io.restassured.RestAssured;
import org.json.simple.JSONObject;

import static io.restassured.RestAssured.given;
import io.restassured.module.jsv.JsonSchemaValidator;


class reqresdemo2 {

	// gets executed only once
	@BeforeAll
	public static void beforeTestExecution() {
		
		RestAssured.baseURI = "https://reqres.in";
	}
	
	@Test
	public void getAllUsersTest() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
			.when()
				.get("/api/users?page=2")
				.then()
				.assertThat()
					.statusCode(200)
					.contentType("application/json");
		
	}
	
	@Test
	public void getAnUserTest() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
			.when()
				.get("/api/users/2")
				.then()
				.assertThat()
					.statusCode(200).and()
					.contentType("application/json").and()
					.body("data.id",equalTo(2)).and()
					.body("data.email",equalTo("janet.weaver@reqres.in")).and()
					.body("data.first_name",equalTo("Janet")).and()
					.body("data.last_name",equalTo("Weaver"));
					
		
	}
	
	
	@Test
	public void createUserTest() {
		RestAssured.useRelaxedHTTPSValidation();
		JSONObject userObj = new JSONObject();
		userObj.put("name", "Sam");
		userObj.put("job", "Lead");
		
		given()
			.contentType("application/json")
			.with()
				.body(userObj.toJSONString())
			.when()
				.post("/api/users")
				.then()
				.assertThat()
					.statusCode(201).and()
					.contentType("application/json").and()
					.body("name",equalTo("Sam")).and()
					.body("job",equalTo("Lead")).and()
					.body("id",not(equalTo(0)));
					
		
	}
	
	
	@Test
	public void updateAnUserTest() {
		RestAssured.useRelaxedHTTPSValidation();
		JSONObject userObj = new JSONObject();
		userObj.put("name", "Sam");
		userObj.put("job", "Lead");
		
		given()
			.contentType("application/json")
			.with()
				.body(userObj.toJSONString())
			.when()
				.put("/api/users/2")
				.then()
				.assertThat()
					.statusCode(200).and()
					.contentType("application/json").and()
					.body("name",equalTo("Sam")).and()
					.body("job",equalTo("Lead"));
		
	}
	

	@Test
	public void deleteAnUserTest() {
		RestAssured.useRelaxedHTTPSValidation();
		given()
			.when()
				.delete("/api/users/2")
				.then()
				.assertThat()
					.statusCode(204).and()
					.time(lessThan(2000l));
		
	}
	
	 @Test
	   public void validateJSONSchema(){
		 RestAssured.useRelaxedHTTPSValidation();
	      //base URL
	      RestAssured.baseURI = "https://jsonplaceholder.typicode.com/posts/2";

	      //obtain response
	      given()
	      .when().get()

	      //verify JSON Schema
	      .then().assertThat()
	      .body(JsonSchemaValidator.matchesJsonSchema(new File("C:\\Users\\d.duraivelan\\Documents\\de1.json")));
	   }
	
}
