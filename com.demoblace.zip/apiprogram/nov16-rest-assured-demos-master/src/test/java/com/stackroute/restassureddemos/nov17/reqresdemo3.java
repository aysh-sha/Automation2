package com.stackroute.restassureddemos.nov17;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.stackroute.restassureddemos.Category;

import io.restassured.RestAssured;
import io.restassured.internal.path.json.mapping.JsonPathGsonObjectDeserializer;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import static io.restassured.RestAssured.given;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.mapping.JsonPathObjectDeserializer;
import io.restassured.response.Response;


class reqresdemo3 {

	// gets executed only once
	@BeforeAll
	public static void beforeTestExecution() {
		
		RestAssured.baseURI = "http://localhost:9001/api/v1";
	}
	
//	@Test
	public void getAllNotesTest() {
		
		
	/*
	*{
        "noteid": "n502",
        "notetitle": "Trip to Chester",
        "description": "Official visit",
        "catylist": null
    }
	*/
//		given()
//			.when()
//				.get("/note")
//				.then()
//				.assertThat()
//					.statusCode(200)
//					.contentType("application/json").and()
//					.body("data[0].noteid",equalTo("n502")).and()
//					.body("data[0.notetitle",equalTo("Trip to Chester")).and()
//					.body("data[0].description",equalTo("Official visit")).and()
//					.body("data[0].catylist",equalTo(null));


		
		Response res = given().get("http://localhost:9001/api/v1/note");
		
		System.out.println(res.statusCode());
		
//		System.out.println(res.asPrettyString());
		
		JsonPath jsonpath = new JsonPath(res.asString());
		
//		System.out.println(jsonpath.prettify());
//		
//		System.out.println(jsonpath.getString("$[1]"));
		
		System.out.println(jsonpath.getList("$").get(0));
//		System.out.println(jsonpath.getList("$").get(1));
//		System.out.println(jsonpath.getList("$").get(2));
//		
		
	}
	
	
	@Test
	public void createNoteTest() {
		
		JSONObject noteObj = new JSONObject();
		
		List<Category> clist = new ArrayList<>();
		clist.add(new Category("c001", "official"));
//		
		noteObj.put("noteid", "n214");
		noteObj.put("notetitle", "Trip to Delhi");
		noteObj.put("description", "Official visit");
		noteObj.put("catylist",clist);
		
		
		// converting list of categories fails, it results in status 400 error
		Response res = given()
				.contentType("application/json")
				.with()
				.body(noteObj.toJSONString())
				.when()
				.post("/note")
				.thenReturn();


		System.out.println(res.statusCode());
		
		JsonPath jsonpath = new JsonPath(res.asString());

//		
		System.out.println(jsonpath.prettify());
//					
//		System.out.println(jsonpath.getString("noteid"));
//		System.out.println(jsonpath.getString("notetitle"));
//		System.out.println(jsonpath.getString("description"));
//		System.out.println(jsonpath.getList("catylist"));
//		
//		assertEquals(201,res.statusCode());
//		assertEquals("n206",jsonpath.getString("noteid"));
//		assertEquals("Trip to Delhi",jsonpath.getString("notetitle"));
//		assertEquals("Official visit",jsonpath.getString("description"));
//		assertEquals(null,jsonpath.getList("catylist"));
//		
		// status - 409 conflict - data already exist
//		assertEquals(409,res.statusCode())
		
		
		given()
				.contentType("application/json")
					.with()
						.body(noteObj.toJSONString())
				.when()
					.post("/note")
				.then()
					.assertThat()
//						.body(JsonSchemaValidator.matchesJsonSchema(new File("C:\\Users\\d.duraivelan\\Documents\\de1.json")))
//						.and()
						.body("data.noteid",equalTo("n214"));
						
		

		
		
		
		
		
		
	}
	
		
}
