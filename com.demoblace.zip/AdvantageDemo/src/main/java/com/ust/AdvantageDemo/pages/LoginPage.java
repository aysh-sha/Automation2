package com.ust.AdvantageDemo.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	public static WebDriver driver;
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(css ="sec-form > sec-view:nth-child(1) > div > input")
	public WebElement username;
	@FindBy(css ="div.login.ng-scope > sec-form > sec-view:nth-child(2) > div > input")
	public WebElement password;
	@FindBy(css ="div.login.ng-scope > sec-form > div > input")
	public WebElement rememberme;
	@FindBy(id ="sign_in_btn")
	public WebElement SignIn;
	@FindBy(id="signInResultMessage")
	public WebElement signInResultElement;
	public String ErrorMsg ="Incorrect user name or password.";
	public void waits() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(3000);
	}
}
