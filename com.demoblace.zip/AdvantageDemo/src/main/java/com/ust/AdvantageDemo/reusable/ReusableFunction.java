package com.ust.AdvantageDemo.reusable;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReusableFunction {

	public WebDriver driver;
	public Actions actions;

	public ReusableFunction(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickElement(WebElement element) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(d->element.isDisplayed());
		element.click();
	}

	public String getTextString(WebElement element) {
		String text = element.getText();
		return text;
	}

	public void scroll(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView(true);", element);
	}

	public boolean checkurl(String url) {
		if ((driver.getCurrentUrl()).equals(url)) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}

	public void hover(WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.perform();
	}

	public void insertText(String text, WebElement element) {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element.sendKeys(text);
	}

	public boolean insertWorked(String text, WebElement element) {
		if ((element.getAttribute("value")).equals(text)) {
			return true;
		} else {
			return false;
		}
	}

	public void actionClick(WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element);
		actions.click();
		actions.perform();
	}

	public void decreasePrice(WebElement element) {

		WebElement slider = element;

//		int sliderWidth = slider.getSize().getWidth();

		int reductionAmount = 50;

		// Perform the drag action
		Actions actions = new Actions(driver);
		actions.clickAndHold(slider).moveByOffset(-reductionAmount, 0).release().perform();
	}

	public boolean textMatch(WebElement heading, WebElement name) {
		if ((heading.getText()).equals(name.getText())) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isEnabled(WebElement el) {
		if (el.isEnabled()) {
			return true;
		} else {
			return false;
		}
	}

	public void dealCaptcha(WebElement el) {
		boolean isDisplayed = false;
		while (!isDisplayed) {
			try {
				Thread.sleep(5000); // Check every 5 seconds to be more responsive
				isDisplayed = el.isDisplayed();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt(); // Restore the interrupted status
				e.printStackTrace();
			} catch (org.openqa.selenium.NoSuchElementException
					| org.openqa.selenium.StaleElementReferenceException e) {
				// Element is not present or no longer attached to the DOM
				isDisplayed = false;
			}
		}
	}
	
	public void waitForUrlMatch(String expectedUrl) {
	    boolean isMatched = false;
	    while (!isMatched) {
	        try {
	            Thread.sleep(5000); // Check every 5 seconds to be more responsive
	            isMatched = driver.getCurrentUrl().equals(expectedUrl);
	        } catch (InterruptedException e) {
	            Thread.currentThread().interrupt(); // Restore the interrupted status
	            e.printStackTrace();
	        }
	    }
	}
	
	public boolean isStringMatch(String name,WebElement element) {
		if((element.getText()).contains(name)) {
			return true;
		}else {
			return false;
		}
	}
	
	public boolean isNotPresent(WebElement element) {
	    try {
	        // Attempt to check visibility, will throw an exception if not found
	        return !element.isDisplayed();
	    } catch (org.openqa.selenium.NoSuchElementException e) {
	        // Element not found, which means logout was successful
	        return true;
	    }
	}
	
	public boolean priceMatch(String price,String total) {
		int n = price.length();
		String p = price.substring(1, n);
		if(total.contains(p)) {
			return true;
		}else {
			return false;
		}
	}
	
	public void jsClick(WebElement el) {
		JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("arguments[0].click();", el);
	}
	
	public boolean urlContains(String url) {
		if((driver.getCurrentUrl()).contains(url)) {
			return true;
		}else {
			return false;
		}
	}
}
