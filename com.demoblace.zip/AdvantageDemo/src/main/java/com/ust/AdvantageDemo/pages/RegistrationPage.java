package com.ust.AdvantageDemo.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.AdvantageDemo.reusable.ReusableFunction;

public class RegistrationPage {
	public WebDriver driver;
	public ReusableFunction rf;
	
	@FindBy(name = "usernameRegisterPage")
	public  WebElement Username;
	@FindBy(name = "emailRegisterPage")
	public  WebElement Email;
	@FindBy(name = "passwordRegisterPage")
	public  WebElement Password;
	@FindBy(name = "confirm_passwordRegisterPage")
	public WebElement Confirm_password;
	@FindBy(name = "first_nameRegisterPage")
	public  WebElement First_name;
	@FindBy(name = "last_nameRegisterPage")
	public  WebElement Last_name;
	@FindBy(name = "phone_numberRegisterPage")
	public  WebElement phone_number;
	@FindBy(name = "countryListboxRegisterPage")
	public  WebElement Country;
	@FindBy(name = "cityRegisterPage")
	public  WebElement City;
	@FindBy(name = "addressRegisterPage")
	public  WebElement Address;
	@FindBy(name = "state_/_province_/_regionRegisterPage")
	public  WebElement State;
	@FindBy(name="postal_codeRegisterPage")
	public  WebElement Postal_Code;
	@FindBy(name="allowOffersPromotion")
	public  WebElement allowOffersPromotion;
	@FindBy(name="i_agree")
	public  WebElement i_agree;
	@FindBy(id = "register_btn")
	public  WebElement Register_btn;
	@FindBy(css="#menuUserLink > span")
	public WebElement userid;
	@FindBy(xpath = "//*[@id=\"registerPage\"]/article/sec-form/div[2]/label[1]")
	public WebElement ErrorElement;
	public String ErrorMsg1 = "Incorrect user name or password.";
	public String ErrorMsg2 = "User name already exists";
	
	public RegistrationPage(WebDriver driver){
		this.driver=driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunction(driver);
	}
	public void inputDetails(WebElement element,String detail) {
		element.sendKeys(detail);
	}
	public void clickElement(WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(d->element.isDisplayed());
		rf.clickElement(element);
	}
}
