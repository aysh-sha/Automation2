package com.ust.AdvantageDemo.pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ust.AdvantageDemo.reusable.ReusableFunction;

public class HomePage {
	WebDriver driver;
	LoginPage lp;
	ReusableFunction rf;
	
	
//	@FindBy(id = "menuUserLink")
//	public static WebElement menu_user_link;
	public By menuUserLink = By.id("menuUserLink");
	@FindBy(linkText  = "CREATE NEW ACCOUNT")
	public static WebElement create_account_button;
	@FindBy(css="#menuUserLink > span")
	public WebElement userid;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		rf = new ReusableFunction(driver);
	}
	
	public String getUrl() {
		return driver.getCurrentUrl();
	}
	public LoginPage clickUserIcon() throws InterruptedException {
		WebElement menu_user_link = driver.findElement(menuUserLink);
//		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		Thread.sleep(5000);
//		wait.until(v->menu_user_link.isDisplayed());
		rf.clickElement(menu_user_link);
		Thread.sleep(5000);
		return new LoginPage(driver);
	}
	public RegistrationPage clickRegisterbtn() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(30));
		wait.until(d -> create_account_button.isDisplayed());
		rf.clickElement(create_account_button);
		return new RegistrationPage(driver);
	}

	public void waits() throws InterruptedException {
		// TODO Auto-generated method stub
		Thread.sleep(5000);
	}

}
