package step_definitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

import com.ust.AdvantageDemo.pages.HomePage;
import com.ust.AdvantageDemo.pages.LoginPage;
import com.ust.AdvantageDemo.pages.RegistrationPage;
import com.ust.AdvantageDemo.utils.ExcelDataReader;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {
	
	WebDriver driver = Hooks.driver;
	Properties properties = Hooks.properties;
	HomePage hp;
	LoginPage lp;
	RegistrationPage rp;
	
	@DataProvider(name="invalidLogin")
	public Object[][] invalidLogin() throws IOException{
		return ExcelDataReader.readDataFromSheet(properties.getProperty("invalid"),System.getProperty("user.dir")+"\\Datas\\advantageRegistrationDetail.xlsx");
	}
	
	
	@Given("Iam already on homepage")
	public void iam_already_on_homepage() throws InterruptedException {
		driver.get(properties.getProperty("home"));
		hp = new HomePage(driver);
		Thread.sleep(5000);
		assertEquals(properties.getProperty("home"),hp.getUrl());
	}
	@When("I click usericon button")
	public void i_click_usericon_button() throws InterruptedException {
		  lp = hp.clickUserIcon();
	}
	@Then("Iam redirected to login popup")
	public void iam_redirected_to_login_popup() {
	    assertEquals(lp.SignIn.getText(), "SIGN IN");
	}
	@When("I enter invalid {string} and {string}")
	public void i_enter_invalid_and(String string, String string2) throws InterruptedException {
	    lp.username.sendKeys(string);
	    lp.password.sendKeys(string2);
	    lp.rememberme.click();
	    lp.SignIn.click();
	    lp.waits();
	    
	    
	}
	@Then("Error message is shown or Iam still in the same page")
	public void error_message_is_shown_or_iam_still_in_the_same_page() {
		System.out.println(lp.SignIn.isEnabled());
	    if(!(lp.SignIn.isEnabled())) {
	    	assertTrue(true);
	    }
	    else if(lp.signInResultElement.getText().contains(lp.ErrorMsg)) {
	    	assertTrue(true);
	    }
	}
	@When("I enter valid username and password")
	public void i_enter_valid_username_and_password() {
	    lp.username.sendKeys(properties.getProperty("username"));
	    lp.password.sendKeys(properties.getProperty("password"));
	    lp.rememberme.click();
	    lp.SignIn.click();
	}
	@Then("Iam redirected to home page")
	public void iam_redirected_to_home_page() throws InterruptedException {
		hp.waits();
	    assertTrue(hp.userid.getText().contains(properties.getProperty("username")));
	}
}
