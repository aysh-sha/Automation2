package com.ust.AdvantageDemo.tests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.AdvantageDemo.base.SetUp;
import com.ust.AdvantageDemo.pages.HomePage;
import com.ust.AdvantageDemo.pages.LoginPage;
import com.ust.AdvantageDemo.pages.RegistrationPage;
import com.ust.AdvantageDemo.utils.ExcelDataReader;
import com.ust.AdvantageDemo.utils.ExtentReportsListener;
@Listeners(ExtentReportsListener.class)
public class RegistrationTest extends SetUp {
  HomePage hp;
  RegistrationPage rp;
  LoginPage lp;
  @Test(priority = 1)
  public void loadHomePage() throws InterruptedException {
	  driver.get(properties.getProperty("home"));
	  hp = new HomePage(driver);
	  waits(2000);
	  assertEquals(properties.getProperty("home"),hp.getUrl());
  }
  @Test(priority = 2)
  public void loadRegistrationPage() throws InterruptedException {
	  lp =hp.clickUserIcon();
	  rp = hp.clickRegisterbtn();
	  
  }
  @Test(priority = 3 , dataProvider = "dp")
  public void validateRegistration(String username,String email,String password,String confirmpassword,String firstname, String lastname,String phoneno,String country,String city,String address,String state,String postcode ) throws InterruptedException {
	  rp.inputDetails(rp.Username,username);
	  rp.inputDetails(rp.Email, email);
	  rp.inputDetails(rp.Password, password);
	  rp.inputDetails(rp.Confirm_password,confirmpassword);
	  rp.inputDetails(rp.First_name,firstname);
	  rp.inputDetails(rp.Last_name,lastname );
	  rp.inputDetails(rp.phone_number,phoneno);
	  rp.inputDetails(rp.Country,country);
	  rp.inputDetails(rp.City,city);
	  rp.inputDetails(rp.Address, address);
	  rp.inputDetails(rp.State, state);
	  rp.inputDetails(rp.Postal_Code, postcode);
	  rp.clickElement(rp.allowOffersPromotion);
	  rp.clickElement(rp.i_agree);
	  Thread.sleep(10000);
	  rp.clickElement(rp.Register_btn);
	  waits(3000);
	  if(rp.ErrorElement.getText().contains(rp.ErrorMsg1) || rp.ErrorElement.getText().contains(rp.ErrorMsg2) ) {
		  System.out.println(rp.ErrorElement.getText());
		  assertTrue(true);
	  }
	  else {
		  System.out.println("Registration successful");
		  assertEquals(rp.userid.getText(), username); 
	  }

  }
  @DataProvider
  public String[][] dp() throws IOException{
	  return ExcelDataReader.readDataFromSheet("formDetails", System.getProperty("user.dir")+"\\Datas\\advantageRegistrationDetail.xlsx");
  }
}
