package runner;

import io.cucumber.testng.*;

@CucumberOptions(
		glue="step_definitions",
		features = "src/test/resources/features/login.feature",
//		dryRun = true,
		plugin = {"pretty",
				"com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
				"timeline:test-output-thread/"
		}

	)

public class TestRunner extends AbstractTestNGCucumberTests{

}