package javacodebasics;

/*public class Simple {

	public static void main(String[] args) {
		System.out.println("Hello World");

	}*/


public class Simple{  
public static void main(String args[]){  
int x=10;  
System.out.println(x++);//10 (11)  
System.out.println(++x);//12  
System.out.println(x--);//12 (11)  
System.out.println(--x);//10  
}}  