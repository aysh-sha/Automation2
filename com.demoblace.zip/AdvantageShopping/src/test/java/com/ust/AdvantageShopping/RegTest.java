package com.ust.AdvantageShopping;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import baseUI.ReusableFunctions;
import baseUI.SetUp;
import pages.LoginPage;
import pages.ProductsPage;
import pages.UserReg;
import utilities.ExtentReportListener;

@Listeners(ExtentReportListener.class)
public class RegTest extends SetUp {
	UserReg ur;
	ReusableFunctions rf;
	
	public RegTest() throws IOException {
		super();
		// TODO Auto-generated constructor stub
	}
 
	LoginPage lp;
	ProductsPage pp;
	@BeforeTest
	public void setup() {
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
	}
	@AfterTest
	public void teardown() {
		driver.quit();
	}
  
  @Test(priority = 0)
	public void loadLoginPage() {
		
		ur = new UserReg(driver);
		assertTrue(ur.checkUrl(prop.getProperty("baseurl")), "Failed to load base url");
	}

	@Test(priority = 1)
	public void clickRegister() throws InterruptedException {
		ur.click(ur.userregistration);
		Thread.sleep(2000);
		ur.click(ur.newacc);
		Thread.sleep(2000);
		ur.click(ur.registerbtn);
		Thread.sleep(2000);
		wait();
		assertTrue(ur.isPresent(ur.registerbtn), "Login with null data case failed");
		
	}
	@Test(priority = 2)
	public void enterCredentials() throws InterruptedException {
		ur.click(ur.userregistration);
		ur.click(ur.newacc);
		ur.click(ur.registerbtn);
		ur.enterText(ur.username, prop.getProperty("username"));
		ur.enterText(ur.email, prop.getProperty("email"));
		ur.enterText(ur.password, prop.getProperty("password"));
		ur.enterText(ur.confrimpassword, prop.getProperty("confirm"));
		ur.enterText(ur.firstname, prop.getProperty("firstname"));
		ur.enterText(ur.lastname, prop.getProperty("lastname"));
		ur.enterText(ur.phonenumber, prop.getProperty("phonenumber"));
		rf.selectdropdown(ur.country,prop.getProperty("country"));
		ur.enterText(ur.city, prop.getProperty("city"));
		ur.enterText(ur.address, prop.getProperty("address"));
		ur.enterText(ur.state, prop.getProperty("state"));
		ur.enterText(ur.postal, prop.getProperty("postal"));
		
		ur.click(ur.checkbox);
		ur.click(ur.registerbtn);
		
		assertTrue(ur.checkUrl(prop.getProperty("register")),"Failed to login");

		Thread.sleep(2000);
		
}
}