package cucumberTest;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;

import baseUI.SetUp;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.LoginPage;
import pages.ProductsPage;
import utilities.ExcelReader;
import utilities.ObjectReader;

public class LoginTest extends SetUp {
	
	LoginPage lp;
	ProductsPage pp;
	
	@Before
	public void setup() throws IOException, InterruptedException
	{  
		prop = ObjectReader.initProperties();
		driver = invokeBrowser();
		driver.get(prop.getProperty("baseurl"));
		Thread.sleep(12000);
		//driver=driver.invokeBrowser(prop.getProperty("browser"));
		//driver.get(ObjectReader.initProperties().getProperty("baseurl"));
		
	}
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(2000);
	driver.quit();
}
	
	@DataProvider(name="dp")
	  public String[][] dp() throws IOException {
		  
	   String path = System.getProperty("user.dir") + "\\DataSource\\Dataexcel.xlsx";
	   String Sheetname= "Sheet1";
	   String [][] data= ExcelReader.excel("C:\\Users\\271559\\Desktop\\Java\\ProjectTask\\DataSource\\Dataexcel.xlsx",Sheetname);
	 
	   return data;
	}
	
@Given("the user in the AdvantageShopping Login page")
public void the_user_in_the_advantage_shopping_login_page() throws InterruptedException {
	lp = new LoginPage(driver);
	driver.get(prop.getProperty("baseurl"));
	lp.menu();
}

@When("the invalid username  is entered")
public void the_invalid_username_is_entered(String username) throws InterruptedException {
	
	

	lp.enterusername(username);
	Thread.sleep(2000);
}

@And("the invalid password is entered")
public void the_invalid_password_is_entered(String password) {
	
	lp.enterpassword(password);
}

@When("the valid username is entered")
public void the_valid_username_is_entered() throws InterruptedException {

	

	lp.enterusername(prop.getProperty("validusername"));
	Thread.sleep(3000);
}

@And("the valid password is entered")
public void the_valid_password_is_entered() {
	
	lp.enterpassword(prop.getProperty("validpassword"));

}

@And("the login button is clicked")
public void the_login_button_is_clicked() throws InterruptedException {
	pp = lp.clicklogin();
	Thread.sleep(3000);
}

@Then("the products page should be displayed")
public void the_products_page_should_be_displayed() {
	String exp = "mahima";
	String actual = lp.namecheck();
	Assert.assertEquals(actual, exp);
}

@Then("an error message should be displayed")
public void an_error_message_should_be_displayed() {
	String errormsg = lp.getErrorMsg();
	assertTrue(errormsg.contains("Incorrect user name or password."));

}

}
