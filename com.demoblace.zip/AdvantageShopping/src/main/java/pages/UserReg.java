package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Listeners;

import baseUI.ReusableFunctions;
import utilities.ExtentReportListener;



public class UserReg {
	WebDriver driver;
	ReusableFunctions rf;
	
	public UserReg(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver,this);
        rf = new ReusableFunctions(driver);
    }
	
	@FindBy(id="menuUserSVGPath")
	public WebElement userregistration;
	
	@FindBy(linkText="CREATE NEW ACCOUNT")
	public WebElement newacc; 
	
	@FindBy(name="usernameRegisterPage")
	public WebElement username;
	
	@FindBy(name="emailRegisterPage")
	public WebElement email;
	
	@FindBy(name="passwordRegisterPage")
	public WebElement password;
	
	@FindBy(name="confirm_passwordRegisterPage")
	public WebElement confrimpassword;
	
	@FindBy(name="first_nameRegisterPage")
	public WebElement firstname ;
	
	@FindBy(name="last_nameRegisterPage")
	public WebElement lastname;
	
	@FindBy(name="phone_numberRegisterPage")
	public WebElement phonenumber ;
	
	@FindBy(name="countryListboxRegisterPage")
	public WebElement country ;
	
	@FindBy(name="cityRegisterPage")
	public WebElement city;
	
	@FindBy(name="addressRegisterPage")
	public WebElement address;
	
	@FindBy(name="state_/_province_/_regionRegisterPage")
	public WebElement state;
	
	@FindBy(name="postal_codeRegisterPage")
	public WebElement postal ;
	
	@FindBy(name="i_agree")
	public WebElement checkbox ;
	
	@FindBy(id="register_btn")
	public WebElement registerbtn ;
	
	
	public UserReg enterText(WebElement element, String txt) {
		element.clear();
		rf.insertText(txt, element);
		return this;
 
	}
 
	public void click(WebElement element) {
		rf.clickElement(element);
	}
	public boolean isPresent(WebElement element) {
		return rf.isPresent(element);
	}
 
	public boolean checkUrl(String property) {
		return rf.checkurl(property);
	}
	
}

