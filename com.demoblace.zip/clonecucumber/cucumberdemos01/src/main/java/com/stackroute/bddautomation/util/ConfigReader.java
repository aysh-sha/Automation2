package com.stackroute.bddautomation.util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ConfigReader {
	
	
	public static String getPropertyVal(String propertyname) throws IOException {
		Properties prop = new Properties();
		prop.load(new FileReader(System.getProperty("user.dir")+"/config/dataconfig.properties"));
		return prop.getProperty(propertyname);
	}
	

}
