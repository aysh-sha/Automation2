package com.stackroute.bddautomation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchPO {
	
	WebDriver driver;
	
	public SearchPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(css="input[id^='gh']:nth-child(2)")
	private WebElement searchfield;
	
	@FindBy(css="input[id^='gh']:nth-child(1)")
	private WebElement searchbtn;
	
	public void enterSearchText(String searchtxt) {
		searchfield.sendKeys(searchtxt);
	}

	public SearchResultsPO submitSearch() {
		searchbtn.submit();
		return new SearchResultsPO(driver);
	}
}
