package com.stackroute.bddautomation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class SearchResultsPO {

	WebDriver driver;
	
	public SearchResultsPO(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public String getCurrentURL() {
		return driver.getCurrentUrl();
	}
}
