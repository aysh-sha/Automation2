package com.stackroute.bddautomation;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		features = {"D:\\NCS-Automation\\CucumberDemosm21\\bddautomation\\src\\test\\java\\com\\stackroute\\bddautomation"},
		glue = {"com.stackroute.bddautomation"},
		publish = true,
		plugin = {"me.jvt.cucumber.report.PrettyReports:target/ustreports"},
		tags = "@regressiontest"
		)
public class CucumberRunner extends AbstractTestNGCucumberTests{

}

//dryRun = true
//tags = "@smoketest and @regressiontest"
//tags = "@smoketest"
//tags = "not @finalregression"