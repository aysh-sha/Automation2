package com.stackroute.bddautomation;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.sql.DriverManager;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.stackroute.bddautomation.browser.DriverFactory;
import com.stackroute.bddautomation.pages.SearchPO;
import com.stackroute.bddautomation.pages.SearchResultsPO;
import com.stackroute.bddautomation.util.ConfigReader;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SearchTest {
	
	WebDriver driver;
	SearchPO spo;
	SearchResultsPO srpo;
	
	@BeforeAll(order=1)
	public static void beforeAll() {
	    System.out.println("Before all - beforeAll");
	}
	
	
	@BeforeAll(order=2)
	public static void beforeAll2() {
	    System.out.println("Before all - beforeAll2");
	}
	
	
	@Before
	public void setup() throws IOException {
		driver = DriverFactory.getDriver(ConfigReader.getPropertyVal("browser"));
	}
	
	@After
	public void teardown() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
	}

	@Given("the user in the eBay home page")
	public void the_user_in_the_e_bay_home_page() throws IOException {
		driver.get(ConfigReader.getPropertyVal("baseurl"));
	}
	
	@When("the search string is entered")
	public void the_search_string_is_entered() {
		spo = new SearchPO(driver);
		spo.enterSearchText("Samsung");		
	}
	
	@And("a category is selected")
	public void a_category_is_selected() {
		System.out.println("Inside And method - I");
	}
	
	@And("the search button is clicked")
	public void the_search_button_is_clicked() {
		srpo = spo.submitSearch();
	}
	
	@Then("the search results page for the category selected should be displayed")
	public void the_search_results_page_for_the_category_selected_should_be_displayed() {
		System.out.println("Inside Then method - I");
	}

	@Then("the search results page should be displayed")
	public void the_search_results_page_should_be_displayed() {
		assertTrue(srpo.getCurrentURL().contains("_nkw=Samsung"));
		assertTrue(srpo.getCurrentURL().contains("_sacat=0"));	
    }

}
