package TestcaseJPetStore;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import PagesJPetStore.HomePage;
import PagesJPetStore.LandingPage;
import objectRepositoryReader.Objectreader;
import utils.BrowserImplementation;


public class VerifyLandingPage {
	
	  WebDriver driver;
	  LandingPage lp;
	  BrowserImplementation bi;
	  Objectreader or;
	  HomePage hp;
	  
	
	@Test(priority=1)
	
	public void LandingPage() throws InterruptedException, IOException
	{
		
		bi = new BrowserImplementation();
		driver = bi.LaunchChrome();
		
		or = new Objectreader();
		driver.get(or.getBaseUrl());
		
		
		//driver.get("https://petstore.octoperf.com/");
		lp = new LandingPage(driver);
		lp.verify_URL();
		lp.verify_Title();
		lp.verify_WelcomeText();
		lp.verify_CopyRightMsg();
		lp.verify_EnterStoreLink();
		Thread.sleep(3000);
		
		
	}
	
	/*
	 * public void tearDown() {
	 * 
	 * driver.quit(); }
	 */  
	@Test(priority=2)

  public void Homepage() throws IOException
	  {   
		  HomePage hp= new HomePage(driver);
		  hp.signin();
		  
		  hp.validDetails_login();
		  driver.quit();
		 
			
	  }
	
}
