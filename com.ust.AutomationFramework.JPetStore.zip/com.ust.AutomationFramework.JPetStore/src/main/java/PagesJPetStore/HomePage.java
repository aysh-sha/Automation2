package PagesJPetStore;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import objectRepositoryReader.Objectreader;
 
public class HomePage {
 
	WebDriver driver;
	Objectreader or;
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
	}
	public void signin()
	{
		driver.findElement(By.linkText("Sign In")).click();
	}
	public void validDetails_login() throws IOException
	{
		//this.driver=driver;
		or = new Objectreader();
		
		  WebElement uname =driver.findElement(By.name("username"));
		  uname.sendKeys(or.getusername());
		  WebElement pswd =driver.findElement(By.name("password")); 
		  pswd.clear(); 
		  pswd.sendKeys(or.getpassword());
		  driver.findElement(By.name("signon")).click();
		 
	}
}



 