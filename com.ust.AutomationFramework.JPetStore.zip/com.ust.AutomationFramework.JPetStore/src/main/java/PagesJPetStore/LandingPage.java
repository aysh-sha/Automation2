package PagesJPetStore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class LandingPage
{
	WebDriver driver;
	public LandingPage(WebDriver driver){
		this.driver = driver;
	}

	public void verify_URL(){
		System.out.println(driver.getCurrentUrl());
	}
	
	
	public void verify_Title(){
		System.out.println(driver.getTitle());
	}
	
	public void verify_WelcomeText(){
		WebElement welcomeText = driver.findElement(By.xpath("//h2[contains(text(),'Welcome to JPetStore 6')]"));
		System.out.println(welcomeText.getText());
	}
	
	public void verify_CopyRightMsg(){
		WebElement cy_Msg = driver.findElement(By.xpath("//sub[contains(text(),'Copyright www.mybatis.org')]"));
		System.out.println(cy_Msg.getText());
	}
	
	public void verify_EnterStoreLink(){
		driver.findElement(By.linkText("Enter the Store")).click();
	}
	
}