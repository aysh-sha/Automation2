package utils;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import objectRepositoryReader.Objectreader;

public class BrowserImplementation {
	WebDriver driver;
	

	public WebDriver LaunchChrome() throws IOException {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		return driver;
	}

	public WebDriver LaunchEdge() {
		driver = new EdgeDriver();

		driver.manage().window().maximize();
		return driver;

	}

}