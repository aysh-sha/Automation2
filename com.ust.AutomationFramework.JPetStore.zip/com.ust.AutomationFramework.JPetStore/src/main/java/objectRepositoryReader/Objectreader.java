package objectRepositoryReader;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Objectreader {
	 
		Properties p;
		public Objectreader() throws IOException {
			String objPath = "C:\\Users\\271559\\Desktop\\Java\\com.ust.AutomationFramework.JPetStore\\Object Repository\\Object.properties";
			FileReader reader = new FileReader(objPath);
			p = new Properties();
			p.load(reader);
			System.out.println(p.getProperty("BaseUrl"));
		}
		public String getBaseUrl() {
			return p.getProperty("BaseUrl");
		}
	 
		public String getChromepath() {
			return p.getProperty("path");
		}
		public String getChromeKey() {
			return p.getProperty("ChromeKey");
		}
		public String getusername() {
			return p.getProperty("username");
		}
		public String getpassword() {
			return p.getProperty("password");
		}
	 
	}
	 

	
	
